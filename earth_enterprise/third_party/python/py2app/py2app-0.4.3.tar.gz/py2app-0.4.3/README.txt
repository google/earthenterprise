py2app is a Python setuptools command which will allow
you to make standalone Mac OS X application bundles
and plugins from Python scripts.

py2app is similar in purpose and design to py2exe for
Windows.
