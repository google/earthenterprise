#ifndef SK_DRAW_EXTRA_PATH_EFFECT_H
#define SK_DRAW_EXTRA_PATH_EFFECT_H
class SkAnimator;
void InitializeSkExtraPathEffects(SkAnimator* animator);
#endif

